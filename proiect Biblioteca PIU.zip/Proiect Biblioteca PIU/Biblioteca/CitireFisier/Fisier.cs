﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CitireFisier
{
    public class Fisier
    {
        static void Main(string[] args)
        {
        }
    }
}
